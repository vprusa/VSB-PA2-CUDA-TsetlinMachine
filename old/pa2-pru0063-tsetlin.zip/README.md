# Projekt - Paralelní Alg. 2 - Návrh Tsetlin Machine na GPU

## Autor
Průša Vojtěch, PRU0063

## Dataset

[Secondary Mushroom Dataset](https://archive.ics.uci.edu/dataset/848/secondary+mushroom+dataset)

Ukázkový výstup:
```
head mushroom/MushroomDataset/secondary_data.csv 
class;cap-diameter;cap-shape;cap-surface;cap-color;does-bruise-or-bleed;gill-attachment;gill-spacing;gill-color;stem-height;stem-width;stem-root;stem-surface;stem-color;veil-type;veil-color;has-ring;ring-type;spore-print-color;habitat;season
p;15.26;x;g;o;f;e;;w;16.95;17.09;s;y;w;u;w;t;g;;d;w
p;16.6;x;g;o;f;e;;w;17.99;18.19;s;y;w;u;w;t;g;;d;u
```

## Spuštění

Zdrojové soubory soubory `tsetlin.mushroom.cpp` a starší verze (bastl) v `./old`.

Vyvýjeno na  `nVidia P5300 with Max-Q Design, Win10`.

Spuštění v IDE VisualStudio.

Vstupním parameterm programu je cesta k datovému souboru `secondary_data.csv` nebo ji lze nastavit na pevno ve funkci `main`.


## Výstupy

Log běhu poslední verze k nalezeni v `logs/log.2025-04-23_21-40-45.log`

Souhrn:

```
Thread Config: 32x32
Clauses | Binarization | Flattening | Training | Validation | Total GPU | Total CPU
1       0.0688128 ms    0.0692224 ms    0.065152 ms     0.0452608 ms    0.248448 ms     408.388 ms
2       0.0542784 ms    0.0520192 ms    0.0598272 ms    0.054528 ms     0.220653 ms     407.06 ms
3       0.0684032 ms    0.0499776 ms    0.0676864 ms    0.0538048 ms    0.239872 ms     407.953 ms
4       0.0925696 ms    0.0804864 ms    0.0809472 ms    0.0925632 ms    0.346566 ms     411.376 ms
5       0.0985088 ms    0.0878656 ms    0.08 ms         0.0846528 ms    0.351027 ms     406.789 ms
10      0.103424 ms     0.101178 ms     0.0935424 ms    0.102182 ms     0.400326 ms     406.387 ms
100     0.0995328 ms    0.0856064 ms    0.088064 ms     0.0980352 ms    0.371238 ms     406.562 ms
1000    0.0960576 ms    0.0774144 ms    0.0760576 ms    0.0964992 ms    0.346029 ms     405.723 ms
10000   0.091552 ms     0.0929792 ms    0.073504 ms     0.0830592 ms    0.341094 ms     402.877 ms

Thread Config: 16x16
Clauses | Binarization | Flattening | Training | Validation | Total GPU | Total CPU
1       0.0964544 ms    0.0698304 ms    0.088256 ms     0.0853568 ms    0.339898 ms     403.751 ms
2       0.0964608 ms    0.0811008 ms    0.0919104 ms    0.0798528 ms    0.349325 ms     405.996 ms
3       0.10199 ms      0.075168 ms     0.0804224 ms    0.0866944 ms    0.344275 ms     407.248 ms
4       0.094208 ms     0.0735232 ms    0.0803328 ms    0.0864832 ms    0.334547 ms     404.853 ms
5       0.0976832 ms    0.0780288 ms    0.089184 ms     0.083168 ms     0.348064 ms     403.95 ms
10      0.0958464 ms    0.081504 ms     0.0800448 ms    0.0838336 ms    0.341229 ms     406.341 ms
100     0.111418 ms     0.0823296 ms    0.0780352 ms    0.0920576 ms    0.36384 ms      401.698 ms
1000    0.0976896 ms    0.0804864 ms    0.0786176 ms    0.0909376 ms    0.347731 ms     393.791 ms
10000   0.103834 ms     0.0874432 ms    0.072608 ms     0.077728 ms     0.341613 ms     387.091 ms


```

## Konfigurace

V metodě `main` je možné nastavit konfiguraci:
- `int cuda_iterations = 5;` - počet iterací běhu TM (časy jsou pak zprůměrované)
- ` vector<int> num_clauses_set = { 1, 5, 10000};` - počet použitách klauzulí v dané TM
- konfigurace kernelu `    vector<pair<int, int>> thread_configs = { {32, 32}, {16, 16}, {8, 8} };` pro porovnání běhu s různými konfiguracemi, bruteforce.



## Paralelismus

Paralelismus je na několika úrovních:

### Výčet statistik - CPU + GPU

Funkce programu kernelu `computeStatisticsKernel`, která je potřeba provést pro získání max a min hodnot daných sloupců pro následnou kategorizace.

Funkce `computeStatistics` na CPU nastavuje zpracování dat na GPU pro získání rozsahu později kategorizovanych hodnot. Toto ziskani na GPU je pomoci funkci `reduceMinMax`.

Alternativou této funkce je `computeStatisticsCPU`.


### Rozdělení dat na trénovací a validační - CPU

Rozdělení dat na trénovací a validační, tohle by teoreticky šlo provést na GPU, ale v době, kdy jsem tohle psal jsem tak neuvažoval a pak jsem tuhle část nechal jak je. SOučástí je taky zamíchaní dat pro lepší zpracování správnosti `accuracy` výsledky v každé iteraci `cuda_1` jiné.

### Přírava pro kategorizaci, binarizaci a zplščtění dat - CPU

Na CPU proběhne v několika fázích příprava načtenáých dat na kategorizaci na GPU - převod stringů a definice limitů dle dříve získaných statistik.

### Kategorizace - GPU

Kernel program `categorizeKernel`, ktery kategorizaci (na zloštěných datech) na GPU a připraví tak data pro trenovani a validaci - tedy tento program funguje nad 2 paměťových prostorech a to pro trenovacich a validacni data.

### Binarizace a zploštení dat - GPU

Nasledne probehne binarizace a zplosteni dat, ktera byla ulozena na v ramci predchozi kroku pomoci kternel programu `binarizeFlattenKernel`. Tato cast take probiha pro trenovaci a validacni data.

### Trénování TM - GPU

Data jsou pripravena a tedy je spusteni trenovani TM pomoci programu `trainTM_2D` a nastavnei konfigurace kernelu pro trenovani i validaci je pak:

```
    // variables chosen to cover dimensions (dim3):
    //  1. cover the sample dimension
    //    e.g. |samples| = 1025, thread.x = 32 -> (1025 + 32 - 1) / 32 = 33
    //  2. cover all literals (simillar equation as above)
    //  3. per clause
    dim3 blocksTrain((train_size + threads.x - 1) / threads.x, (num_literals + threads.y - 1) / threads.y, num_clauses);
    dim3 blocksValid((valid_size + threads.x - 1) / threads.x, (num_literals + threads.y - 1) / threads.y, num_clauses);
// ...
    trainTM_2D << <blocksTrain, threads >> > (d_train_flat, d_train_labels, train_size, num_literals, 2, d_states);

``` 

konstanta `2` je `int vote_margin` a slouzi k nastaveni max/min stavu, jeji nataveni v TM ovlivnuje `accuracy`.

Z konfigruace zle vyčíst, že používám `dim3` pro 3D paralelizaci - `vzorek x literal x clause`, ale je 2D paralelizace v programu kernelu `trainTM_2D`, kde upozorním, že zde jsou atomické operace `atomicSub` a `atomicAdd`, které můžou blokovat běh vláken.

Přiznávám, že v této části programu je možné, že jsem něco minul a otázka zní, jak určit do jaké míry je atomičnost blokující?


### Priprava dat pro validaci - GPU

Příprava dat je podobná jako pro trénování - binarizace `binarizeDataKernel` a zploštění `flattenBinarizedDataKernel` (převod na pozitivní a negativní liteláry).

### Validace - GPU

Validace probíhá podobně jako učení a to pomoci programu kernelu funkce `validateTM_2D` pro jednotlivé vzorky dat (1. dimenze) a jednotlive literaly (2. dimenze).

Následuje vykopírování výsledku z paměti GPU, uvolnění paměti, posbírání měření času událostí a pročištění paměti.


## Možná rozšíření


Aktuální verze je 2D paralelismus programu kernelu `trainTM_2D` nad vzorky a literály (pominu-li klauzule) a explicitní 3D by mohlo být například `trainTM_3D` nad:
```
    // 3D indexing...
    int sample_idx  = blockIdx.x * blockDim.x + threadIdx.x;
    int literal_idx = blockIdx.y * blockDim.y + threadIdx.y;
    int clause_idx  = blockIdx.z; // One clause per block in z-dim
```

Dejte prosím vědět, jestli se mám touto cestou dále ubírat praktick a nebo stačí tento teoretický nástin.



