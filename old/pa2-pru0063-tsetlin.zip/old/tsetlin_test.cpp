// Minimalistic C++ Tsetlin Machine Implementation (CPU-side, CUDA-style syntax where possible)
// Assumes binary input features after Booleanization
#include <iostream>
#include <vector>
#include <cassert>
#include <cmath>
#include <cstring>
#include <stdexcept>
#include <random>

//#define MAX_FEATURES 128
//#define NUM_CLAUSES 10
//#define STATES 100

#define MAX_FEATURES 5
#define NUM_CLAUSES 10
#define STATES 20
//#define DEBUG_CLAUSES

// Helper macros (mimicking CUDA behavior)
#define DEVICE_FUNC inline
#define HOST_DEVICE_FUNC inline

#include <fstream>
#include <sstream>
#include <unordered_map>
#include <map>
#include <set>
#include <algorithm>
#include <numeric>
#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct DatasetStats {
    std::unordered_map<std::string, int> category_counts;
    std::set<int> unique_integers;
    std::vector<float> float_values;

    void print_stats() const {
        std::cout << "Category counts:\n";
        for (const auto& [cat, count] : category_counts)
            std::cout << "  " << cat << ": " << count << "\n";

        if (!unique_integers.empty()) {
            std::cout << "\nInteger Stats:\n";
            std::cout << "  Unique count: " << unique_integers.size() << "\n";
            std::cout << "  Min: " << *unique_integers.begin() << ", Max: " << *unique_integers.rbegin() << "\n";
        }

        if (!float_values.empty()) {
            std::cout << "\nFloat Stats:\n";
            float min_val = *std::min_element(float_values.begin(), float_values.end());
            float max_val = *std::max_element(float_values.begin(), float_values.end());
            std::cout << "  Min: " << min_val << ", Max: " << max_val << "\n";

            std::vector<float> diffs;
            for (size_t i = 1; i < float_values.size(); ++i) {
                diffs.push_back(std::abs(float_values[i] - float_values[i - 1]));
            }
            if (!diffs.empty()) {
                float min_d = *std::min_element(diffs.begin(), diffs.end());
                float max_d = *std::max_element(diffs.begin(), diffs.end());
                float avg_d = std::accumulate(diffs.begin(), diffs.end(), 0.0f) / diffs.size();
                std::cout << "  Diff - Min: " << min_d << ", Max: " << max_d << ", Avg: " << avg_d << "\n";
            }
        }
    }
};

struct HeartDataEntry {
    int age;
    bool sex_bool; // 2 values
    int cp_category; // 
    int trestbps;
    int chol;
    bool fbs;
    int restecg;
    int thalach;
    float exang;
    float oldpeak;
    int slope;
    int ca;
    int thal;
    int target;
};


struct DatasetSchema {
    enum ColumnType { BOOL, CATEGORY, INTEGER, FLOAT };
    std::vector<std::pair<int, ColumnType>> column_mapping; // column index in file, column type
    std::vector<DatasetStats> stats;

    DatasetSchema(size_t count) : stats(count) {}
};

std::vector<HeartDataEntry> load_heart_dataset(const std::string& filename, DatasetSchema& schema) {
    std::ifstream infile(filename);
    std::string line;
    std::vector<HeartDataEntry> dataset;
    int skipped = 0;

    // Mappings for categorical values
    static std::unordered_map<std::string, int> cp_map, restecg_map, slope_map, thal_map;

    while (std::getline(infile, line)) {
        if (line.empty() || line[0] == '%') {
            skipped++;
            continue;
        }

        std::istringstream iss(line);
        std::vector<std::string> tokens;
        std::string token;
        while (iss >> token) {
            tokens.push_back(token);
        }

        if (tokens.size() < 14) {
            skipped++;
            continue;
        }

        HeartDataEntry entry;

        try {
            entry.age       = std::stoi(tokens[0]);
            entry.sex_bool  = (tokens[1] == "male");

            if (cp_map.find(tokens[2]) == cp_map.end()) cp_map[tokens[2]] = cp_map.size();
            entry.cp_category = cp_map[tokens[2]];

            entry.trestbps  = std::stoi(tokens[3]);
            entry.chol      = std::stoi(tokens[4]);
            entry.fbs       = (tokens[5] == "true");

            if (restecg_map.find(tokens[6]) == restecg_map.end()) restecg_map[tokens[6]] = restecg_map.size();
            entry.restecg   = restecg_map[tokens[6]];

            entry.thalach   = std::stoi(tokens[7]);
            entry.exang     = (tokens[8] == "true") ? 1.0f : 0.0f;
            entry.oldpeak   = std::stof(tokens[9]);

            if (slope_map.find(tokens[10]) == slope_map.end()) slope_map[tokens[10]] = slope_map.size();
            entry.slope     = slope_map[tokens[10]];

            entry.ca        = (tokens[11] == "?") ? 0 : static_cast<int>(std::stof(tokens[11]));

            if (thal_map.find(tokens[12]) == thal_map.end()) thal_map[tokens[12]] = thal_map.size();
            entry.thal      = thal_map[tokens[12]];

            entry.target    = (tokens[13] == "buff") ? 0 : 1;

            // === Dynamically track stats ===
            for (size_t i = 0; i < schema.column_mapping.size(); ++i) {
                int col = schema.column_mapping[i].first;
                auto type = schema.column_mapping[i].second;
                const std::string& val = tokens[col];

                switch (type) {
                    case DatasetSchema::BOOL:
                    case DatasetSchema::CATEGORY:
                        schema.stats[i].category_counts[val]++;
                        break;
                    case DatasetSchema::INTEGER:
                        try {
                            schema.stats[i].unique_integers.insert(std::stoi(val));
                        } catch (...) {}
                        break;
                    case DatasetSchema::FLOAT:
                        try {
                            schema.stats[i].float_values.push_back(std::stof(val));
                        } catch (...) {}
                        break;
                }
            }

            dataset.push_back(entry);
        } catch (const std::exception& e) {
            std::cerr << "Skipping line due to parse error: " << e.what() << "\n";
            skipped++;
        }
    }

    std::cout << "Loaded " << dataset.size() << " entries from " << filename
              << ", Skipped: " << skipped << " malformed lines\n";
    return dataset;
}


// Tsetlin Automaton per literal
struct TsetlinAutomaton {
    int state;

    TsetlinAutomaton() : state(STATES / 2) {}

    DEVICE_FUNC bool isIncluded() const {
        return state > STATES / 2;
    }

    DEVICE_FUNC void reward() {
        if (state < STATES) state++;
    }

    DEVICE_FUNC void penalize() {
        if (state > 1) state--;
    }
};

// A Clause is a conjunction of literals (features or their negations)
/*
struct Clause {
    std::vector<TsetlinAutomaton> automata_pos;
    std::vector<TsetlinAutomaton> automata_neg;
    int output;

    Clause(int num_features) : automata_pos(num_features), automata_neg(num_features), output(0) {}

    DEVICE_FUNC int evaluate(const std::vector<int>& features) {
        for (size_t i = 0; i < features.size(); ++i) {
            if ((automata_pos[i].isIncluded() && !features[i]) ||
                (automata_neg[i].isIncluded() && features[i])) {
                return 0;
            }
        }
        return 1;
    }

    void update(const std::vector<int>& features, int target_output, float s = 3.0f) {
        int clause_output = evaluate(features);
        if (target_output == 1) { // positive feedback
            if (clause_output == 1) {
                for (size_t i = 0; i < features.size(); ++i) {
                    if (features[i]) automata_pos[i].reward();
                    else automata_neg[i].reward();
                }
            }
        } else { // negative feedback (target_output == 0)
            if (clause_output == 1) { // false positive, selectively penalize
                for (size_t i = 0; i < features.size(); ++i) {
                    if (features[i]) automata_pos[i].penalize();
                    else automata_neg[i].penalize();
                }
            }
        }
    }
};
*/

// A Clause is a conjunction of literals (features or their negations)
struct Clause {
    std::vector<TsetlinAutomaton> automata_pos;  // Automata managing inclusion of positive literals
    std::vector<TsetlinAutomaton> automata_neg;  // Automata managing inclusion of negated literals
    int output;

    Clause(int num_features) : automata_pos(num_features), automata_neg(num_features), output(0) {}

    // Evaluates the clause against a binary input feature vector.
    // Returns 1 if clause evaluates to true (i.e., all included literals are satisfied), else 0.
    DEVICE_FUNC int evaluate(const std::vector<int>& features) {
        for (size_t i = 0; i < features.size(); ++i) {
            // Clause fails if an included positive literal does not match
            if (automata_pos[i].isIncluded() && !features[i]) return 0;
            // Clause fails if an included negated literal is violated
            if (automata_neg[i].isIncluded() && features[i]) return 0;
        }
        return 1;  // Clause is satisfied
    }

    // Updates automata based on whether clause output matches target class
    void update(const std::vector<int>& features, int target_output, float modifier = 3.0f) {
        int clause_output = evaluate(features);

        if (target_output == 1) {
            // POSITIVE FEEDBACK: Clause should fire
            if (clause_output == 1) {
                for (size_t i = 0; i < features.size(); ++i) {
                    if (features[i]) {
                        // Reinforce positive literal inclusion
                        automata_pos[i].reward();
                    } else {
                        // Reinforce negative literal inclusion for absent features
                        automata_neg[i].reward();
                    }
                }
            }
        } else {
            // NEGATIVE FEEDBACK: Clause should NOT fire
            if (clause_output == 1) {
                for (size_t i = 0; i < features.size(); ++i) {
                    if (features[i]) {
                        // Discourage inclusion of true features that wrongly triggered clause
                        automata_pos[i].penalize();
                    } else {
                        // Discourage inclusion of negated features that failed to prevent firing
                        automata_neg[i].penalize();
                    }
                }
            }
        }
    }
};

struct TsetlinMachine {
    std::vector<Clause> clauses;
    int num_features;

    TsetlinMachine(int features) : num_features(features) {
        for (int i = 0; i < NUM_CLAUSES; ++i)
            clauses.emplace_back(features);
    }

    int predict(const std::vector<int>& features) {
        int vote = 0;
        for (size_t i = 0; i < clauses.size(); ++i) {
            vote += clauses[i].evaluate(features) ? 1 : 0;
        }
        return vote > NUM_CLAUSES / 2 ? 1 : 0;
    }

    void train(const std::vector<int>& features, int label) {
        for (auto& clause : clauses) {
            clause.update(features, label);
        }
    }

    void print_stats() const {
        std::cout << "\nTsetlin Machine Stats:\n";
        for (size_t c = 0; c < clauses.size(); ++c) {
            int included = 0;
            for (size_t f = 0; f < num_features; ++f) {
                if (clauses[c].automata_pos[f].isIncluded() || clauses[c].automata_neg[f].isIncluded())
                    included++;
            }
#ifdef DEBUG_CLAUSES
            std::cout << "Clause " << c << ": " << included << " active literals\n";
#endif
        }
    }

    // After prediction, in TsetlinMachine
    void print_clause_votes(const std::vector<int>& features) {
        std::cout << "Clause outputs: ";
        for (size_t i = 0; i < clauses.size(); ++i) {
            std::cout << clauses[i].evaluate(features) << " ";
        }
        std::cout << "\n";
    }

    void print_state_distribution() const {
        int pos_mem = 0, pos_forg = 0, neg_mem = 0, neg_forg = 0;
        for (const auto& clause : clauses) {
            for (const auto& a : clause.automata_pos)
                (a.state > STATES/2 ? pos_mem : pos_forg)++;
            for (const auto& a : clause.automata_neg)
                (a.state > STATES/2 ? neg_mem : neg_forg)++;
        }
        std::cout << "Pos Automata - Memorized: " << pos_mem << ", Forgotten: " << pos_forg << "\n";
        std::cout << "Neg Automata - Memorized: " << neg_mem << ", Forgotten: " << neg_forg << "\n";
    }


};

// === TEST CASES === //
void run_test(void (*test_func)(), const std::string& test_name) {
    try {
        test_func();
//        std::cout << test_name << " passed.\n";
        std::cout << "\033[32m" << test_name << " passed." << "\033[0m" << std::endl;
    } catch (const std::exception& ex) {
//        std::cout << test_name << " failed: " << ex.what() << "\n";
        std::cout << "\033[31m" << test_name << " failed: " << ex.what() << "\033[0m" << std::endl;
    }
}

#define DEFINE_TEST(n) void test_case_##n()

DEFINE_TEST(1) {
    std::cout << "Test 1: 1 category (sex) - single data\n";
    TsetlinMachine tm(1);
    std::vector<int> sample = {1};
    tm.train(sample, 1);
    int pred = tm.predict(sample);
    std::cout << "Expected: 1, Predicted: " << pred << "\n";
    tm.print_stats();
    if (pred != 1) throw std::runtime_error("Prediction != 1");
}

DEFINE_TEST(2) {
    std::cout << "Test 2: 2 categories (sex, age_type) - single each\n";
    TsetlinMachine tm(2);
    std::vector<int> sample1 = {1, 0};
    std::vector<int> sample2 = {0, 1};

    for (int i = 0; i < 4; ++i) {
        tm.train(sample1, 1);
        std::cout << "After training with sample1, iteration " << i + 1 << ":\n";
        tm.print_stats();
        tm.train(sample2, 0);
        std::cout << "After training with sample2, iteration " << i + 1 << ":\n";
        tm.print_stats();
    }

    int pred1 = tm.predict(sample1);
    std::cout << "Clause votes for sample1: ";
    tm.print_clause_votes(sample1);

    int pred2 = tm.predict(sample2);
    std::cout << "Clause votes for sample2: ";
    tm.print_clause_votes(sample2);

    std::cout << "Expected: 1, Predicted: " << pred1 << "\n";
    std::cout << "Expected: 0, Predicted: " << pred2 << "\n";
    tm.print_stats();
    tm.print_state_distribution();

    if (pred1 != 1) throw std::runtime_error("sample1 failed");
    if (pred2 != 0) throw std::runtime_error("sample2 failed");
}

DEFINE_TEST(3) {
    std::cout << "Test 3: sex - multiple data\n";
    TsetlinMachine tm(1);
    for (int i = 0; i < 10; ++i) tm.train({1}, 1);
    for (int i = 0; i < 5; ++i) tm.train({0}, 0);
    int pred1 = tm.predict({1});
    int pred2 = tm.predict({0});
    std::cout << "Expected: 1, Predicted: " << pred1 << "\n";
    std::cout << "Expected: 0, Predicted: " << pred2 << "\n";
    tm.print_stats();
    if (pred1 != 1) throw std::runtime_error("male failed");
    if (pred2 != 0) throw std::runtime_error("female failed");
}

DEFINE_TEST(4) {
    std::cout << "Test 4: sex+age_type - multiple data\n";
    TsetlinMachine tm(2);
    for (int i = 0; i < 10; ++i) tm.train({1, 0}, 1);
    for (int i = 0; i < 10; ++i) tm.train({0, 1}, 0);
    int pred1 = tm.predict({1, 0});
    int pred2 = tm.predict({0, 1});
    std::cout << "Expected: 1, Predicted: " << pred1 << "\n";
    std::cout << "Expected: 0, Predicted: " << pred2 << "\n";
    tm.print_stats();
    if (pred1 != 1) throw std::runtime_error("male adult failed");
    if (pred2 != 0) throw std::runtime_error("female kid failed");
}

DEFINE_TEST(5) {
    std::cout << "Test 5: sex+age(int) - single data\n";
    TsetlinMachine tm(8);
    std::vector<int> input(8, 0);
    input[0] = 1; input[3] = 1;
    tm.train(input, 1);
    int pred = tm.predict(input);
    std::cout << "Expected: 1, Predicted: " << pred << "\n";
    tm.print_stats();
    if (pred != 1) throw std::runtime_error("prediction failed");
}

DEFINE_TEST(6) {
    std::cout << "Test 6: sex+age(int) - multiple\n";
    TsetlinMachine tm(8);
    std::vector<int> m16(8, 0), f80(8, 0);
    m16[0] = 1; m16[3] = 1;
    f80[1] = 1; f80[6] = 1;
    for (int i = 0; i < 20; ++i) tm.train(m16, 1);
    for (int i = 0; i < 10; ++i) tm.train(f80, 0);
    int pred1 = tm.predict(m16);
    int pred2 = tm.predict(f80);
    std::cout << "Expected: 1, Predicted: " << pred1 << "\n";
    std::cout << "Expected: 0, Predicted: " << pred2 << "\n";
    tm.print_stats();
    if (pred1 != 1) throw std::runtime_error("m16 failed");
    if (pred2 != 0) throw std::runtime_error("f80 failed");
}

DEFINE_TEST(7) {
    std::cout << "Test 7: 1 float feature (weight)\n";
    TsetlinMachine tm(8);
    std::vector<int> sample(8, 0);
    sample[3] = 1;
    tm.train(sample, 1);
    int pred = tm.predict(sample);
    std::cout << "Expected: 1, Predicted: " << pred << "\n";
    tm.print_stats();
    if (pred != 1) throw std::runtime_error("prediction failed");
}

DEFINE_TEST(8) {
    std::cout << "Test 8: sex + weight (float)\n";
    TsetlinMachine tm(9);
    std::vector<int> input(9, 0);
    input[0] = 1;
    input[4] = 1;
    tm.train(input, 1);
    int pred = tm.predict(input);
    std::cout << "Expected: 1, Predicted: " << pred << "\n";
    tm.print_stats();
    if (pred != 1) throw std::runtime_error("prediction failed");
}

DEFINE_TEST(9) {
    std::cout << "Test 9: sex + weight (float) - multiple\n";
    TsetlinMachine tm(9);
    std::vector<int> m100(9, 0), f50(9, 0);
    m100[0] = 1; m100[4] = 1;
    f50[1] = 1; f50[2] = 1;
    for (int i = 0; i < 20; ++i) tm.train(m100, 1);
    for (int i = 0; i < 10; ++i) tm.train(f50, 0);
    int pred1 = tm.predict(m100);
    int pred2 = tm.predict(f50);
    std::cout << "Expected: 1, Predicted: " << pred1 << "\n";
    std::cout << "Expected: 0, Predicted: " << pred2 << "\n";
    tm.print_stats();
    if (pred1 != 1) throw std::runtime_error("m100 failed");
    if (pred2 != 0) throw std::runtime_error("f50 failed");
}

DEFINE_TEST(10) {
    std::cout << "\nStarting test 10\n";
    DatasetSchema schema(13);
    schema.column_mapping = {
            {0, DatasetSchema::INTEGER},  // age
            {1, DatasetSchema::BOOL},     // sex
            {2, DatasetSchema::CATEGORY}, // cp
            {3, DatasetSchema::INTEGER},  // trestbps
            {4, DatasetSchema::INTEGER},  // chol
            {5, DatasetSchema::BOOL},     // fbs
            {6, DatasetSchema::CATEGORY}, // restecg
            {7, DatasetSchema::INTEGER},  // thalach
            {8, DatasetSchema::BOOL},     // exang
            {9, DatasetSchema::FLOAT},    // oldpeak
            {10, DatasetSchema::CATEGORY},// slope
            {11, DatasetSchema::INTEGER}, // ca
            {12, DatasetSchema::CATEGORY} // thal
    };
    auto data = load_heart_dataset("cleve.mod", schema);

    const char* labels[] = {
            "Age", "Sex", "CP", "Trestbps", "Chol", "FBS", "RestECG",
            "Thalach", "Exang", "Oldpeak", "Slope", "CA", "Thal"
    };

    for (size_t i = 0; i < schema.stats.size(); ++i) {
        std::cout << "\n-- " << labels[i] << " Stats --\n";
        schema.stats[i].print_stats();
    }
}
/*
DEFINE_TEST(11) {
    std::cout << "\nStarting test 11\n";
    DatasetSchema schema(4);
    schema.column_mapping = {
            {1, DatasetSchema::BOOL}, {2, DatasetSchema::CATEGORY}, {0, DatasetSchema::INTEGER}, {8, DatasetSchema::FLOAT}};
    std::vector<HeartDataEntry> data = load_heart_dataset("cleve.mod", schema);
    TsetlinMachine tm(1);
    std::vector<int> input1 = {data[3].sex_bool}; // true
    std::vector<int> input2 = {data[4].sex_bool}; // false
    tm.train(input1, data[3].target);
    tm.train(input2, data[4].target);
    int pred1 = tm.predict(input1);
    std::cout << "Expected: " << data[3].target << ", Predicted: " << pred1 << "\n";
    if (pred1 != data[3].target) throw std::runtime_error("test11 failed on sample 1");
}

DEFINE_TEST(12) {
    DatasetSchema schema(4);
    schema.column_mapping = {
            {1, DatasetSchema::BOOL}, {2, DatasetSchema::CATEGORY}, {0, DatasetSchema::INTEGER}, {8, DatasetSchema::FLOAT}};
    auto data = load_heart_dataset("cleve.mod", schema);
    TsetlinMachine tm(1);
    for (int i : {0, 1, 2}) {
        const std::vector<int>& features = {data[i].cp_category};
        int label = data[i].target;
        tm.train(features, label);
    }
    for (int i : {3, 4, 5}) {
        const std::vector<int>& features = {data[i].cp_category};
        int label = data[i].target;
        tm.train(features, label);
    }
    int pred = tm.predict({data[0].cp_category});
    std::cout << "Expected: " << data[0].target << ", Predicted: " << pred << "\n";
    if (pred != data[0].target) throw std::runtime_error("test12 failed");
}

DEFINE_TEST(13) {
    DatasetSchema schema(4);
    schema.column_mapping = {
            {1, DatasetSchema::BOOL}, {2, DatasetSchema::CATEGORY}, {0, DatasetSchema::INTEGER}, {8, DatasetSchema::FLOAT}};
    auto data = load_heart_dataset("cleve.mod", schema);
    TsetlinMachine tm(2);
    for (int i = 0; i < 5; ++i)
        tm.train({data[i].sex_bool, data[i].age}, data[i].target);
    int pred = tm.predict({data[0].sex_bool, data[0].age});
    std::cout << "Expected: " << data[0].target << ", Predicted: " << pred << "\n";
    if (pred != data[0].target) throw std::runtime_error("test13 failed");
}*/

DEFINE_TEST(11) {
    std::cout << "\nStarting test 11\n";
    DatasetSchema schema(4);
    schema.column_mapping = {
            {1, DatasetSchema::BOOL}, {2, DatasetSchema::CATEGORY}, {0, DatasetSchema::INTEGER}, {8, DatasetSchema::FLOAT}};

    std::vector<HeartDataEntry> data = load_heart_dataset("cleve.mod", schema);
    TsetlinMachine tm(1);

    std::vector<int> input1 = {data[3].sex_bool};
    std::vector<int> input2 = {data[4].sex_bool};
    int target1 = 0;
    int target2 = 1;
//    tm.train(input1, data[3].target);
//    tm.train(input2, data[4].target);
    tm.train(input1, target1);
    tm.train(input2, target2);

    std::cout << "Tsetlin Machine Stats after training:\n";
    tm.print_stats();

    int pred1 = tm.predict(input1);
    std::cout << "Expected: " << target1 << ", Predicted: " << pred1 << "\n";
    if (pred1 != target1) throw std::runtime_error("test11 failed on sample 1");
    int pred2 = tm.predict(input2);
    std::cout << "Expected: " << target2 << ", Predicted: " << pred2 << "\n";
    if (pred2 != target2) throw std::runtime_error("test11 failed on sample 2");
}

DEFINE_TEST(12) {
    std::cout << "\nStarting test 12\n";
    DatasetSchema schema(4);
    schema.column_mapping = {
            {1, DatasetSchema::BOOL}, {2, DatasetSchema::CATEGORY}, {0, DatasetSchema::INTEGER}, {8, DatasetSchema::FLOAT}};

    auto data = load_heart_dataset("cleve.mod", schema);
    TsetlinMachine tm(1);
    int target1 = 0;
    int target2 = 1;

    for (int i : {0, 1, 2}) {
        const std::vector<int> features = {data[i].cp_category};
//        int label = data[i].target;
        tm.train(features, target1);
    }

    for (int i : {3, 4, 5}) {
        const std::vector<int> features = {data[i].cp_category};
//        int label = data[i].target;
        tm.train(features, target2);
    }

    std::cout << "Tsetlin Machine Stats after training:\n";
    tm.print_stats();

    int pred1 = tm.predict({data[0].cp_category});
    std::cout << "Expected: " << target1 << ", Predicted: " << pred1 << "\n";
    if (pred1 != target1) throw std::runtime_error("test12 failed on sample1");
    int pred2 = tm.predict({data[3].cp_category});
    std::cout << "Expected: " << target2 << ", Predicted: " << pred2 << "\n";
    if (pred2 != target2) throw std::runtime_error("test12 failed on sample2");
}

DEFINE_TEST(13) {
    std::cout << "\nStarting test 13\n";
    DatasetSchema schema(4);
    schema.column_mapping = {
            {1, DatasetSchema::BOOL}, {2, DatasetSchema::CATEGORY}, {0, DatasetSchema::INTEGER}, {8, DatasetSchema::FLOAT}};

    auto data = load_heart_dataset("cleve.mod", schema);
    TsetlinMachine tm(2);

    int target1 = 1;

    for (int i = 0; i < 5; ++i) {
        tm.train({data[i].sex_bool, data[i].age}, target1);
        std::cout << "Tsetlin Machine Stats after training on sample " << i << ":\n";
        tm.print_stats();
    }

    int pred = tm.predict({data[0].sex_bool, data[0].age});
    std::cout << "Expected: " << target1 << ", Predicted: " << pred << "\n";
    if (pred != target1) throw std::runtime_error("test13 failed");
}

DEFINE_TEST(14) {
    DatasetSchema schema(4);
    schema.column_mapping = {
            {1, DatasetSchema::BOOL}, {2, DatasetSchema::CATEGORY}, {0, DatasetSchema::INTEGER}, {8, DatasetSchema::FLOAT}};
    auto data = load_heart_dataset("cleve.mod", schema);
    TsetlinMachine tm(1);
    for (int i = 0; i < 5; ++i)
        tm.train({static_cast<int>(data[i].exang)}, data[i].target);
    int pred = tm.predict({static_cast<int>(data[0].exang)});
    std::cout << "Expected: " << data[0].target << ", Predicted: " << pred << "\n";
    if (pred != data[0].target) throw std::runtime_error("test14 failed");
}

DEFINE_TEST(15) {
    DatasetSchema schema(4);
    schema.column_mapping = {
            {1, DatasetSchema::BOOL}, {2, DatasetSchema::CATEGORY}, {0, DatasetSchema::INTEGER}, {8, DatasetSchema::FLOAT}};
    auto data = load_heart_dataset("cleve.mod", schema);

    std::shuffle(data.begin(), data.end(), std::default_random_engine(static_cast<unsigned>(time(nullptr))));
    size_t split = (data.size() * 2) / 3;

    TsetlinMachine tm(4);
    for (size_t i = 0; i < split; ++i) {
        std::vector<int> input = {
                static_cast<int>(data[i].sex_bool),
                data[i].cp_category,
                data[i].age,
                static_cast<int>(data[i].exang)};
        tm.train(input, data[i].target);
    }

    int correct = 0;
    int total = 0;
    for (size_t i = split; i < data.size(); ++i) {
        std::vector<int> input = {
                static_cast<int>(data[i].sex_bool),
                data[i].cp_category,
                data[i].age,
                static_cast<int>(data[i].exang)};
        int pred = tm.predict(input);
        if (pred == data[i].target) correct++;
        total++;
    }

    float accuracy = 100.0f * correct / total;
    std::cout << "Test 15 - Accuracy on validation set: " << accuracy << "% (" << correct << "/" << total << ")\n";
    if (accuracy < 50.0f) throw std::runtime_error("Test 15 - accuracy too low");
}

DEFINE_TEST(16) {
    std::cout << "\nStarting Test 16: Full Feature Set\n";

    std::vector<std::pair<int, DatasetSchema::ColumnType>> full_columns = {
            {0, DatasetSchema::INTEGER},  // age
            {1, DatasetSchema::BOOL},     // sex
            {2, DatasetSchema::CATEGORY}, // cp
            {3, DatasetSchema::INTEGER},  // trestbps
            {4, DatasetSchema::INTEGER},  // chol
            {5, DatasetSchema::BOOL},     // fbs
            {6, DatasetSchema::CATEGORY}, // restecg
            {7, DatasetSchema::INTEGER},  // thalach
            {8, DatasetSchema::BOOL},     // exang
            {9, DatasetSchema::FLOAT},    // oldpeak
            {10, DatasetSchema::CATEGORY},// slope
            {11, DatasetSchema::INTEGER}, // ca
            {12, DatasetSchema::CATEGORY} // thal
    };

    DatasetSchema schema(full_columns.size());
    schema.column_mapping = full_columns;

    std::vector<HeartDataEntry> data;
    try {
        data = load_heart_dataset("cleve.mod", schema);
    } catch (const std::exception& ex) {
        std::cerr << "Error loading dataset: " << ex.what() << "\n";
        throw;
    }

    std::shuffle(data.begin(), data.end(), std::default_random_engine(static_cast<unsigned>(time(nullptr))));
    size_t split = (data.size() * 2) / 3;

    std::cout << "Training on " << split << " samples, validating on " << (data.size() - split) << " samples\n";

    TsetlinMachine tm(schema.column_mapping.size());
    for (size_t i = 0; i < split; ++i) {
        std::vector<int> input;
        input.push_back(data[i].age);
        input.push_back(static_cast<int>(data[i].sex_bool));
        input.push_back(data[i].cp_category);
        input.push_back(0); // Placeholder for trestbps
        input.push_back(0); // Placeholder for chol
        input.push_back(0); // Placeholder for fbs
        input.push_back(0); // Placeholder for restecg
        input.push_back(0); // Placeholder for thalach
        input.push_back(static_cast<int>(data[i].exang));
        input.push_back(0); // Placeholder for oldpeak
        input.push_back(0); // Placeholder for slope
        input.push_back(0); // Placeholder for ca
        input.push_back(0); // Placeholder for thal
        tm.train(input, data[i].target);
    }

    int correct = 0, total = 0;
    for (size_t i = split; i < data.size(); ++i) {
        std::vector<int> input;
        input.push_back(data[i].age);
        input.push_back(static_cast<int>(data[i].sex_bool));
        input.push_back(data[i].cp_category);
        input.push_back(0);
        input.push_back(0);
        input.push_back(0);
        input.push_back(0);
        input.push_back(0);
        input.push_back(static_cast<int>(data[i].exang));
        input.push_back(0);
        input.push_back(0);
        input.push_back(0);
        input.push_back(0);
        int pred = tm.predict(input);
        if (pred == data[i].target) correct++;
        total++;
    }

    float accuracy = 100.0f * correct / total;
    std::cout << "Test 16 - Accuracy with all columns: " << accuracy << "% (" << correct << "/" << total << ")\n";
    if (accuracy < 50.0f) throw std::runtime_error("Test 16 - accuracy too low");
}

DEFINE_TEST(17) {
    std::cout << "\nStarting test 17: 9/10 train, 1/10 validate (stratified)\n";
    DatasetSchema schema(13);
    schema.column_mapping = {
            {0, DatasetSchema::INTEGER},  {1, DatasetSchema::BOOL},     {2, DatasetSchema::CATEGORY},
            {3, DatasetSchema::INTEGER},  {4, DatasetSchema::INTEGER},  {5, DatasetSchema::BOOL},
            {6, DatasetSchema::CATEGORY}, {7, DatasetSchema::INTEGER},  {8, DatasetSchema::BOOL},
            {9, DatasetSchema::FLOAT},    {10, DatasetSchema::CATEGORY},{11, DatasetSchema::INTEGER},
            {12, DatasetSchema::CATEGORY}
    };

    auto data = load_heart_dataset("cleve.mod", schema);

    std::vector<HeartDataEntry> positives, negatives;
    for (const auto& entry : data) {
        if (entry.target == 1) positives.push_back(entry);
        else negatives.push_back(entry);
    }

    std::shuffle(positives.begin(), positives.end(), std::default_random_engine(static_cast<unsigned>(time(nullptr))));
    std::shuffle(negatives.begin(), negatives.end(), std::default_random_engine(static_cast<unsigned>(time(nullptr))));

    size_t train_pos = (positives.size() * 9) / 10;
    size_t train_neg = (negatives.size() * 9) / 10;

    std::vector<HeartDataEntry> train_data, test_data;
    train_data.insert(train_data.end(), positives.begin(), positives.begin() + train_pos);
    train_data.insert(train_data.end(), negatives.begin(), negatives.begin() + train_neg);
    test_data.insert(test_data.end(), positives.begin() + train_pos, positives.end());
    test_data.insert(test_data.end(), negatives.begin() + train_neg, negatives.end());

    std::shuffle(train_data.begin(), train_data.end(), std::default_random_engine(static_cast<unsigned>(time(nullptr))));
    std::shuffle(test_data.begin(), test_data.end(), std::default_random_engine(static_cast<unsigned>(time(nullptr))));

    TsetlinMachine tm(schema.column_mapping.size());

    for (const auto& e : train_data) {
        std::vector<int> input = {
                e.age, static_cast<int>(e.sex_bool), e.cp_category, e.trestbps, e.chol,
                static_cast<int>(e.fbs), e.restecg, e.thalach, static_cast<int>(e.exang),
                static_cast<int>(e.oldpeak), e.slope, e.ca, e.thal
        };
        tm.train(input, e.target);
    }

    int correct = 0, total = 0;
    for (const auto& e : test_data) {
        std::vector<int> input = {
                e.age, static_cast<int>(e.sex_bool), e.cp_category, e.trestbps, e.chol,
                static_cast<int>(e.fbs), e.restecg, e.thalach, static_cast<int>(e.exang),
                static_cast<int>(e.oldpeak), e.slope, e.ca, e.thal
        };
        int pred = tm.predict(input);
        if (pred == e.target) correct++;
        total++;
    }

    float accuracy = 100.0f * correct / total;
    std::cout << "Test 17 - Accuracy (stratified 9/10 train, 1/10 validate): "
              << accuracy << "% (" << correct << "/" << total << ")\n";
    if (accuracy < 50.0f) throw std::runtime_error("Test 17 - accuracy too low");
}

#define __CUDACC__
#ifdef __CUDACC__
#include <cuda_runtime.h>
#include <device_launch_parameters.h>

__global__ void kernel_train(int* d_features, int* d_labels, int num_samples, int num_features) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < num_samples) {
        // Simple dummy operation: just read the data
        int sum = 0;
        for (int f = 0; f < num_features; ++f) {
            sum += d_features[idx * num_features + f];
        }
        // In real case: update automata or vote logic here
    }
}

void cuda(int maxSteps = 0, bool parallel = true) {
    std::cout << "\n--- CUDA Setup (maxSteps=" << maxSteps << ") ---\n";

    static constexpr float TRAIN_RATIO = 0.666f;
    const int num_features = 4;

    std::vector<HeartDataEntry> data;
    std::vector<std::vector<int>> mapped_features;
    std::vector<int> labels;

    // 2.1 Load the data to RAM
    if (maxSteps >= 1) {
        DatasetSchema schema(4);
        schema.column_mapping = {
                {1, DatasetSchema::BOOL},     // sex
                {2, DatasetSchema::CATEGORY}, // cp
                {0, DatasetSchema::INTEGER},  // age
                {8, DatasetSchema::FLOAT}     // exang
        };
        data = load_heart_dataset("cleve.mod", schema);
        std::cout << "Data loaded. Samples: " << data.size() << "\n";
    }

    // 2.2 Mapping the data to GPU-compatible format
    if (maxSteps >= 2) {
        int min_age = INT32_MAX, max_age = 0;
        float min_exang = FLT_MAX, max_exang = 0;
        for (const HeartDataEntry& row : data) {
            std::vector<int> input = {
                    static_cast<int>(row.sex_bool),
                    row.cp_category,
                    row.age,
                    static_cast<int>(row.exang)
            };
            mapped_features.push_back(input);
            labels.push_back(row.target);

            min_age = std::min(min_age, row.age);
            max_age = std::max(max_age, row.age);
            min_exang = std::min(min_exang, row.exang);
            max_exang = std::max(max_exang, row.exang);
        }
        std::cout << "Mapping complete. Feature bounds:\n";
        std::cout << "  Age: min=" << min_age << ", max=" << max_age << "\n";
        std::cout << "  Exang (float): min=" << min_exang << ", max=" << max_exang << "\n";
    }

    // 2.3 Store mapped data to GPU (2/3 for training)
    int* d_features = nullptr;
    int* d_labels = nullptr;
    size_t train_samples = 0;
    if (maxSteps >= 3) {
        train_samples = static_cast<size_t>(mapped_features.size() * TRAIN_RATIO);
        std::vector<int> flat_features;
        for (size_t i = 0; i < train_samples; ++i) {
            for (int val : mapped_features[i]) {
                flat_features.push_back(val);
            }
        }

        cudaMalloc(&d_features, flat_features.size() * sizeof(int));
        cudaMalloc(&d_labels, train_samples * sizeof(int));

        cudaMemcpy(d_features, flat_features.data(), flat_features.size() * sizeof(int), cudaMemcpyHostToDevice);
        cudaMemcpy(d_labels, labels.data(), train_samples * sizeof(int), cudaMemcpyHostToDevice);
        std::cout << "Copied " << train_samples << " training samples to GPU.\n";
    }

    // 2.4 Check GPU memory content
    if (maxSteps >= 4) {
        int check_sample[4];
        cudaMemcpy(&check_sample, d_features, 4 * sizeof(int), cudaMemcpyDeviceToHost);
        std::cout << "Sample data from GPU: [";
        for (int i = 0; i < 4; ++i) std::cout << check_sample[i] << (i < 3 ? ", " : "]\n");
    }

    // 2.5 Define training kernel execution
    if (maxSteps >= 5) {
        if (parallel) {
            int threads_per_block = 256;
            int blocks = (train_samples + threads_per_block - 1) / threads_per_block;
            kernel_train<<<blocks, threads_per_block>>>(d_features, d_labels, static_cast<int>(train_samples), num_features);
            cudaDeviceSynchronize();
            std::cout << "Executed kernel_train on GPU.\n";
        } else {
            std::cout << "(Simulation only: skipping kernel execution)\n";
        }
    }

    // 2.6 Retrieve and print training results (dummy summary)
    if (maxSteps >= 6) {
        std::cout << "[Step 2.6] Training summary:\n";
        std::cout << " - GPU training was simulated with kernel_train\n";
        std::cout << " - No actual automaton updates are performed yet\n";
        std::cout << " - Placeholder accuracy or clause statistics not available\n";
    }

    // 2.7.1 Validate on CPU
    if (maxSteps >= 7) {
        size_t start_idx = static_cast<size_t>(mapped_features.size() * TRAIN_RATIO);
        int correct = 0, total = 0;
        for (size_t i = start_idx; i < mapped_features.size(); ++i) {
            int sum = 0;
            for (int val : mapped_features[i]) sum += val;
            int prediction = sum % 2;  // dummy logic: even sum => class 0, odd => class 1
            if (prediction == labels[i]) correct++;
            total++;
        }
        float acc = 100.0f * correct / total;
        std::cout << "[CPU] Validation Accuracy: " << acc << "% (" << correct << "/" << total << ")\n";
    }

    // 2.7.2 Validate on GPU
    if (maxSteps >= 8) {
        std::cout << "[GPU] Validation kernel not yet implemented\n";
    }


    if (maxSteps >= 3) {
        cudaFree(d_features);
        cudaFree(d_labels);
        std::cout << "Freed GPU memory.\n";
    }
//    std::cout << "CUDA is not enabled. Steps >= 3 skipped.\n";
}
#endif


int main() {
    std::cout << "\nTesting started.\n";
    run_test(test_case_1, "Test 1");
    run_test(test_case_2, "Test 2");
    run_test(test_case_3, "Test 3");
    run_test(test_case_4, "Test 4");
    run_test(test_case_5, "Test 5");
    run_test(test_case_6, "Test 6");
    run_test(test_case_7, "Test 7");
    run_test(test_case_8, "Test 8");
    run_test(test_case_9, "Test 9");
    run_test(test_case_10, "Test 10");
    run_test(test_case_11, "Test 11");
    run_test(test_case_12, "Test 12");
    run_test(test_case_13, "Test 13");
    run_test(test_case_14, "Test 14");
    run_test(test_case_15, "Test 15");
    run_test(test_case_16, "Test 16");
    run_test(test_case_17, "Test 17");
    std::cout << "\nTesting completed.\n";
#ifdef __CUDACC__
    cuda();
#endif
    return 0;
}
