// Minimalistic C++ Tsetlin Machine Implementation (CPU-side, CUDA-style syntax where possible)
// Assumes binary input features after Booleanization
#include <iostream>
#include <vector>
#include <cassert>
#include <cmath>
#include <cstring>
#include <stdexcept>
#include <random>

//#define MAX_FEATURES 128
//#define NUM_CLAUSES 10
//#define STATES 100

#define MAX_FEATURES 5
#define NUM_CLAUSES 5
#define STATES 5

// Helper macros (mimicking CUDA behavior)
#define DEVICE_FUNC inline
#define HOST_DEVICE_FUNC inline

#include <fstream>
#include <sstream>
#include <unordered_map>
#include <map>
#include <set>
#include <algorithm>
#include <numeric>
#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct DatasetStats {
    std::unordered_map<std::string, int> category_counts;
    std::set<int> unique_integers;
    std::vector<float> float_values;

    void print_stats() const {
        std::cout << "Category counts:\n";
        for (const auto& [cat, count] : category_counts)
            std::cout << "  " << cat << ": " << count << "\n";

        if (!unique_integers.empty()) {
            std::cout << "\nInteger Stats:\n";
            std::cout << "  Unique count: " << unique_integers.size() << "\n";
            std::cout << "  Min: " << *unique_integers.begin() << ", Max: " << *unique_integers.rbegin() << "\n";
        }

        if (!float_values.empty()) {
            std::cout << "\nFloat Stats:\n";
            float min_val = *std::min_element(float_values.begin(), float_values.end());
            float max_val = *std::max_element(float_values.begin(), float_values.end());
            std::cout << "  Min: " << min_val << ", Max: " << max_val << "\n";

            std::vector<float> diffs;
            for (size_t i = 1; i < float_values.size(); ++i) {
                diffs.push_back(std::abs(float_values[i] - float_values[i - 1]));
            }
            if (!diffs.empty()) {
                float min_d = *std::min_element(diffs.begin(), diffs.end());
                float max_d = *std::max_element(diffs.begin(), diffs.end());
                float avg_d = std::accumulate(diffs.begin(), diffs.end(), 0.0f) / diffs.size();
                std::cout << "  Diff - Min: " << min_d << ", Max: " << max_d << ", Avg: " << avg_d << "\n";
            }
        }
    }
};

struct HeartDataEntry {
    int age;
    bool sex_bool;
    int cp_category;
    int trestbps;
    int chol;
    bool fbs;
    int restecg;
    int thalach;
    float exang;
    float oldpeak;
    int slope;
    int ca;
    int thal;
    int target;
};


struct DatasetSchema {
    enum ColumnType { BOOL, CATEGORY, INTEGER, FLOAT };
    std::vector<std::pair<int, ColumnType>> column_mapping; // column index in file, column type
    std::vector<DatasetStats> stats;

    DatasetSchema(size_t count) : stats(count) {}
};

std::vector<HeartDataEntry> load_heart_dataset(const std::string& filename, DatasetSchema& schema) {
    std::ifstream infile(filename);
    std::string line;
    std::vector<HeartDataEntry> dataset;
    int skipped = 0;

    // Mappings for categorical values
    static std::unordered_map<std::string, int> cp_map, restecg_map, slope_map, thal_map;

    while (std::getline(infile, line)) {
        if (line.empty() || line[0] == '%') {
            skipped++;
            continue;
        }

        std::istringstream iss(line);
        std::vector<std::string> tokens;
        std::string token;
        while (iss >> token) {
            tokens.push_back(token);
        }

        if (tokens.size() < 14) {
            skipped++;
            continue;
        }

        HeartDataEntry entry;

        try {
            entry.age       = std::stoi(tokens[0]);
            entry.sex_bool  = (tokens[1] == "male");

            if (cp_map.find(tokens[2]) == cp_map.end()) cp_map[tokens[2]] = cp_map.size();
            entry.cp_category = cp_map[tokens[2]];

            entry.trestbps  = std::stoi(tokens[3]);
            entry.chol      = std::stoi(tokens[4]);
            entry.fbs       = (tokens[5] == "true");

            if (restecg_map.find(tokens[6]) == restecg_map.end()) restecg_map[tokens[6]] = restecg_map.size();
            entry.restecg   = restecg_map[tokens[6]];

            entry.thalach   = std::stoi(tokens[7]);
            entry.exang     = (tokens[8] == "true") ? 1.0f : 0.0f;
            entry.oldpeak   = std::stof(tokens[9]);

            if (slope_map.find(tokens[10]) == slope_map.end()) slope_map[tokens[10]] = slope_map.size();
            entry.slope     = slope_map[tokens[10]];

            entry.ca        = (tokens[11] == "?") ? 0 : static_cast<int>(std::stof(tokens[11]));

            if (thal_map.find(tokens[12]) == thal_map.end()) thal_map[tokens[12]] = thal_map.size();
            entry.thal      = thal_map[tokens[12]];

            entry.target    = (tokens[13] == "buff") ? 0 : 1;

            // === Dynamically track stats ===
            for (size_t i = 0; i < schema.column_mapping.size(); ++i) {
                int col = schema.column_mapping[i].first;
                auto type = schema.column_mapping[i].second;
                const std::string& val = tokens[col];

                switch (type) {
                    case DatasetSchema::BOOL:
                    case DatasetSchema::CATEGORY:
                        schema.stats[i].category_counts[val]++;
                        break;
                    case DatasetSchema::INTEGER:
                        try {
                            schema.stats[i].unique_integers.insert(std::stoi(val));
                        } catch (...) {}
                        break;
                    case DatasetSchema::FLOAT:
                        try {
                            schema.stats[i].float_values.push_back(std::stof(val));
                        } catch (...) {}
                        break;
                }
            }

            dataset.push_back(entry);
        } catch (const std::exception& e) {
            std::cerr << "Skipping line due to parse error: " << e.what() << "\n";
            skipped++;
        }
    }

    std::cout << "Loaded " << dataset.size() << " entries from " << filename
              << ", Skipped: " << skipped << " malformed lines\n";
    return dataset;
}


// Tsetlin Automaton per literal
struct TsetlinAutomaton {
    int state;

    TsetlinAutomaton() : state(STATES / 2) {}

    DEVICE_FUNC bool isIncluded() const {
        return state > STATES / 2;
    }

    DEVICE_FUNC void reward() {
        if (state < STATES) state++;
    }

    DEVICE_FUNC void penalize() {
        if (state > 1) state--;
    }
};

// A Clause is a conjunction of literals (features or their negations)
struct Clause {
    std::vector<TsetlinAutomaton> automata_pos;
    std::vector<TsetlinAutomaton> automata_neg;
    int output;

    Clause(int num_features) : automata_pos(num_features), automata_neg(num_features), output(0) {}

    DEVICE_FUNC int evaluate(const std::vector<int>& features) {
        for (size_t i = 0; i < features.size(); ++i) {
            if ((automata_pos[i].isIncluded() && !features[i]) ||
                (automata_neg[i].isIncluded() && features[i])) {
                return 0;
            }
        }
        return 1;
    }

    void update(const std::vector<int>& features, int target_output, float s = 3.0f) {
        int clause_output = evaluate(features);
        if (target_output == 1) { // positive feedback
            if (clause_output == 1) {
                for (size_t i = 0; i < features.size(); ++i) {
                    if (features[i]) automata_pos[i].reward();
                    else automata_neg[i].reward();
                }
            }
        } else { // negative feedback (target_output == 0)
            if (clause_output == 1) { // false positive, selectively penalize
                for (size_t i = 0; i < features.size(); ++i) {
                    if (features[i]) automata_pos[i].penalize();
                    else automata_neg[i].penalize();
                }
            }
        }
    }

};

struct TsetlinMachine {
    std::vector<Clause> clauses;
    int num_features;

    TsetlinMachine(int features) : num_features(features) {
        for (int i = 0; i < NUM_CLAUSES; ++i)
            clauses.emplace_back(features);
    }

    int predict(const std::vector<int>& features) {
        int vote = 0;
        for (size_t i = 0; i < clauses.size(); ++i) {
            vote += clauses[i].evaluate(features) ? 1 : 0;
        }
        return vote > NUM_CLAUSES / 2 ? 1 : 0;
    }

    void train(const std::vector<int>& features, int label) {
        for (auto& clause : clauses) {
            clause.update(features, label);
        }
    }

    void print_stats() const {
        std::cout << "\nTsetlin Machine Stats:\n";
        for (size_t c = 0; c < clauses.size(); ++c) {
            int included = 0;
            for (size_t f = 0; f < num_features; ++f) {
                if (clauses[c].automata_pos[f].isIncluded() || clauses[c].automata_neg[f].isIncluded())
                    included++;
            }
            std::cout << "Clause " << c << ": " << included << " active literals\n";
        }
    }

    // After prediction, in TsetlinMachine
    void print_clause_votes(const std::vector<int>& features) {
        std::cout << "Clause outputs: ";
        for (size_t i = 0; i < clauses.size(); ++i) {
            std::cout << clauses[i].evaluate(features) << " ";
        }
        std::cout << "\n";
    }

    void print_state_distribution() const {
        int pos_mem = 0, pos_forg = 0, neg_mem = 0, neg_forg = 0;
        for (const auto& clause : clauses) {
            for (const auto& a : clause.automata_pos)
                (a.state > STATES/2 ? pos_mem : pos_forg)++;
            for (const auto& a : clause.automata_neg)
                (a.state > STATES/2 ? neg_mem : neg_forg)++;
        }
        std::cout << "Pos Automata - Memorized: " << pos_mem << ", Forgotten: " << pos_forg << "\n";
        std::cout << "Neg Automata - Memorized: " << neg_mem << ", Forgotten: " << neg_forg << "\n";
    }


};

// === TEST CASES === //
void run_test(void (*test_func)(), const std::string& test_name) {
    try {
        test_func();
        std::cout << test_name << " passed.\n";
    } catch (const std::exception& ex) {
        std::cerr << test_name << " failed: " << ex.what() << "\n";
    }
}

#define DEFINE_TEST(n) void test_case_##n()


#ifdef __CUDACC__
#include <cuda_runtime.h>
#include <device_launch_parameters.h>
#endif

#ifdef __CUDACC__
__global__ void kernel_train(int* d_features, int* d_labels, int num_samples, int num_features) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < num_samples) {
        // Simple dummy operation: just read the data
        int sum = 0;
        for (int f = 0; f < num_features; ++f) {
            sum += d_features[idx * num_features + f];
        }
        // In real case: update automata or vote logic here
    }
}
#endif

void cuda(int maxSteps = 0, bool parallel = true) {
    std::cout << "\n--- CUDA Setup (maxSteps=" << maxSteps << ") ---\n";

    static constexpr float TRAIN_RATIO = 0.666f;
    const int num_features = 4;

    std::vector<HeartDataEntry> data;
    std::vector<std::vector<int>> mapped_features;
    std::vector<int> labels;

    // 2.1 Load the data to RAM
    if (maxSteps >= 1) {
        DatasetSchema schema(4);
        schema.column_mapping = {
                {1, DatasetSchema::BOOL},     // sex
                {2, DatasetSchema::CATEGORY}, // cp
                {0, DatasetSchema::INTEGER},  // age
                {8, DatasetSchema::FLOAT}     // exang
        };
        data = load_heart_dataset("cleve.mod", schema);
        std::cout << "Data loaded. Samples: " << data.size() << "\n";
    }

    // 2.2 Mapping the data to GPU-compatible format
    if (maxSteps >= 2) {
        int min_age = INT32_MAX, max_age = 0;
        float min_exang = FLT_MAX, max_exang = 0;
        for (const HeartDataEntry& row : data) {
            std::vector<int> input = {
                    static_cast<int>(row.sex_bool),
                    row.cp_category,
                    row.age,
                    static_cast<int>(row.exang)
            };
            mapped_features.push_back(input);
            labels.push_back(row.target);

            min_age = std::min(min_age, row.age);
            max_age = std::max(max_age, row.age);
            min_exang = std::min(min_exang, row.exang);
            max_exang = std::max(max_exang, row.exang);
        }
        std::cout << "Mapping complete. Feature bounds:\n";
        std::cout << "  Age: min=" << min_age << ", max=" << max_age << "\n";
        std::cout << "  Exang (float): min=" << min_exang << ", max=" << max_exang << "\n";
    }

#ifdef __CUDACC__
    // 2.3 Store mapped data to GPU (2/3 for training)
    int* d_features = nullptr;
    int* d_labels = nullptr;
    size_t train_samples = 0;
    if (maxSteps >= 3) {
        train_samples = static_cast<size_t>(mapped_features.size() * TRAIN_RATIO);
        std::vector<int> flat_features;
        for (size_t i = 0; i < train_samples; ++i) {
            for (int val : mapped_features[i]) {
                flat_features.push_back(val);
            }
        }

        cudaMalloc(&d_features, flat_features.size() * sizeof(int));
        cudaMalloc(&d_labels, train_samples * sizeof(int));

        cudaMemcpy(d_features, flat_features.data(), flat_features.size() * sizeof(int), cudaMemcpyHostToDevice);
        cudaMemcpy(d_labels, labels.data(), train_samples * sizeof(int), cudaMemcpyHostToDevice);
        std::cout << "Copied " << train_samples << " training samples to GPU.\n";
    }

    // 2.4 Check GPU memory content
    if (maxSteps >= 4) {
        int check_sample[4];
        cudaMemcpy(&check_sample, d_features, 4 * sizeof(int), cudaMemcpyDeviceToHost);
        std::cout << "Sample data from GPU: [";
        for (int i = 0; i < 4; ++i) std::cout << check_sample[i] << (i < 3 ? ", " : "]\n");
    }

    // 2.5 Define training kernel execution
    if (maxSteps >= 5) {
        if (parallel) {
            int threads_per_block = 256;
            int blocks = (train_samples + threads_per_block - 1) / threads_per_block;
            kernel_train<<<blocks, threads_per_block>>>(d_features, d_labels, static_cast<int>(train_samples), num_features);
            cudaDeviceSynchronize();
            std::cout << "Executed kernel_train on GPU.\n";
        } else {
            std::cout << "(Simulation only: skipping kernel execution)\n";
        }
    }

    // 2.6 Retrieve and print training results (dummy summary)
    if (maxSteps >= 6) {
        std::cout << "[Step 2.6] Training summary:\n";
        std::cout << " - GPU training was simulated with kernel_train\n";
        std::cout << " - No actual automaton updates are performed yet\n";
        std::cout << " - Placeholder accuracy or clause statistics not available\n";
    }

    // 2.7.1 Validate on CPU
    if (maxSteps >= 7) {
        size_t start_idx = static_cast<size_t>(mapped_features.size() * TRAIN_RATIO);
        int correct = 0, total = 0;
        for (size_t i = start_idx; i < mapped_features.size(); ++i) {
            int sum = 0;
            for (int val : mapped_features[i]) sum += val;
            int prediction = sum % 2;  // dummy logic: even sum => class 0, odd => class 1
            if (prediction == labels[i]) correct++;
            total++;
        }
        float acc = 100.0f * correct / total;
        std::cout << "[CPU] Validation Accuracy: " << acc << "% (" << correct << "/" << total << ")\n";
    }

    // 2.7.2 Validate on GPU
    if (maxSteps >= 8) {
#ifdef __CUDACC__
        size_t start_idx = static_cast<size_t>(mapped_features.size() * TRAIN_RATIO);
        size_t valid_samples = mapped_features.size() - start_idx;

        std::vector<int> flat_valid_features;
        std::vector<int> valid_labels;

        for (size_t i = start_idx; i < mapped_features.size(); ++i) {
            for (int val : mapped_features[i]) {
                flat_valid_features.push_back(val);
            }
            valid_labels.push_back(labels[i]);
        }

        int* d_valid_features;
        int* d_valid_labels;
        int* d_predictions;

        cudaMalloc(&d_valid_features, flat_valid_features.size() * sizeof(int));
        cudaMalloc(&d_valid_labels, valid_samples * sizeof(int));
        cudaMalloc(&d_predictions, valid_samples * sizeof(int));

        cudaMemcpy(d_valid_features, flat_valid_features.data(), flat_valid_features.size() * sizeof(int), cudaMemcpyHostToDevice);
        cudaMemcpy(d_valid_labels, valid_labels.data(), valid_samples * sizeof(int), cudaMemcpyHostToDevice);

        // Kernel for prediction
        __global__ void kernel_predict(int* features, int* predictions, int num_samples, int num_features) {
            int idx = blockIdx.x * blockDim.x + threadIdx.x;
            if (idx < num_samples) {
                int sum = 0;
                for (int f = 0; f < num_features; ++f) {
                    sum += features[idx * num_features + f];
                }
                predictions[idx] = sum % 2; // Dummy logic
            }
        }

        int threads_per_block = 256;
        int blocks = (valid_samples + threads_per_block - 1) / threads_per_block;

        kernel_predict<<<blocks, threads_per_block>>>(d_valid_features, d_predictions, static_cast<int>(valid_samples), num_features);
        cudaDeviceSynchronize();

        std::vector<int> predictions(valid_samples);
        cudaMemcpy(predictions.data(), d_predictions, valid_samples * sizeof(int), cudaMemcpyDeviceToHost);

        int correct = 0;
        for (size_t i = 0; i < valid_samples; ++i) {
            if (predictions[i] == valid_labels[i]) correct++;
        }

        float accuracy = 100.0f * correct / valid_samples;
        std::cout << "[GPU] Validation Accuracy: " << accuracy << "% (" << correct << "/" << valid_samples << ")\n";

        cudaFree(d_valid_features);
        cudaFree(d_valid_labels);
        cudaFree(d_predictions);
#else
        std::cout << "CUDA not enabled. GPU validation skipped.\n";
#endif
    }


    if (maxSteps >= 3) {
        cudaFree(d_features);
        cudaFree(d_labels);
        std::cout << "Freed GPU memory.\n";
    }
#else
    std::cout << "CUDA is not enabled. Steps >= 3 skipped.\n";
#endif
}


int main() {
    std::cout << "\nTesting completed.\n";
    cuda();
    return 0;
}
